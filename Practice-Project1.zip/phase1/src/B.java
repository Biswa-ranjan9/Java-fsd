package phase1.src;

public class B {
	public void mB() {
		A a = new A();
		
		a.x1=23;
		a.x2=23;
		a.x3=23;
		
		 
		// private cannot be accessed in other classes
		// a.x4=23;
		
	
		
	}

}

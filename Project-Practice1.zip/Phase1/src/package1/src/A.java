package package1.src;

public class A {
	public int x1;
	int x2;
	protected int x3=23;
	private int x4;
	
	
	void mA() {
		System.out.println("Hi");	
	}

}

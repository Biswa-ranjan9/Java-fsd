package com.ecommerce.dao;

import java.util.List;

import org.hibernate.SessionFactory;


@Repository
public class EProductDAO {

        @Autowired
    private SessionFactory sessionFactory;

        @SuppressWarnings("unchecked")
        public List<EProductEntity> getAllProducts() {
                return this.sessionFactory.getCurrentSession().createQuery("from EProducts").list();
        }
}

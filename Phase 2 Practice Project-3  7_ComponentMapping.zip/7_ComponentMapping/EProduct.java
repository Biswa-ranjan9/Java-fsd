
public class EProduct {

}
